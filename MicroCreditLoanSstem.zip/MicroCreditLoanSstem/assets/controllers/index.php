<?php
if (!isset($_SERVER['HTTP_REFERER'])) {
    header('location: ../index.php?action=error_500');
}
include('../seassion.php');

if (isset($_POST['searchmember_only'])) {
    $search = $_POST['searchmember_only'];
    $result = search_by_two_column_value("members", "name", $search, "id", $search);
    $response = array();
    $data = array();
    while ($row = mysqli_fetch_array($result['query'])) {
        $data['image'] = isset($row['member_photo']) && file_exists("../" . $row['member_photo']) ? $row['member_photo'] : 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];


        $response[] = array("value" => $row['id'], "label" => $row['name'], "data" => $data);
    }
    echo json_encode($response);
}

//Get Account suggestions
if (isset($_POST['member_search_for_earnings'])) {
    $search = $_POST['member_search_for_earnings'];
    $account_type = isset($_POST['account_search_type']) ? $_POST['account_search_type'] : "";

    $accounts_conditions = "";
    $loop_first = 1;
    if (is_array($account_type)) {
        foreach ($account_type as $key => $value) {
            if ($loop_first == 1) {
                $accounts_conditions .= " AND( account_type='{$value}'";
            } else {
                $accounts_conditions .= " OR account_type='{$value}'";
            }
            $loop_first++;
        }
    }
    if ($loop_first > 1) {
        $accounts_conditions .= ")";
    }

    // if ($ac_type == "admin") {
    //     $result = search_by_two_column_value("members", "name", $search, "id", $search);
    // } elseif ($user_other_info['office_id'] > 0 &&  $user_other_info['branch_id'] > 0) {
    //     $result = manual_query("SELECT * FROM members WHERE (name like '%$search%' OR id like '%$search%' OR mobile LIKE '%$search%') AND branch='{$user_other_info['branch_id']}'");
    // }
    $result = manual_query("SELECT * FROM `accounts` WHERE member_id LIKE '%$search%' $accounts_conditions GROUP BY member_id");
    // $check_query = "SELECT * FROM `accounts` WHERE account_no LIKE '%$search%' $accounts_conditions";
    $response = array();
    $data = array();
    // $response[] = array("value" => "Blank", "label" => "Blank", "data" => $check_query);
    while ($row = mysqli_fetch_assoc($result['query'])) {



        $response[] = array("value" => $row['member_id'], "label" => $row['member_id'], "desc" => $row['account_title'], "data" => $row);
    }
    echo json_encode($response);
}

//Get Loan sumuries
if (isset($_POST['loan_no'])) {
    $loan_no = $_POST['loan_no'];
    $loan_type = isset($_POST['loan_type']) ? $_POST['loan_type'] : "";

     $result = manual_query("SELECT * FROM `loan_account` WHERE loan_type = '$loan_type' AND loan_no LIKE '%$loan_no%'");
    
    
    $response = array();
    $data = array();
    
    while ($row = mysqli_fetch_assoc($result['query'])) {
     // Last installment
    $last_installment = 0;
    $last_row_details = array();
    $loan_transaction = manual_query("SELECT *,SUM(actual_amount) AS total_actual_paid, SUM(profit_amount) AS total_profit_paid, SUM(cash_in) AS total_cash_in, SUM(cash_out) AS total_cash_out FROM transections_details WHERE account_no='$loan_no' AND category = '$loan_type' ORDER BY id DESC LIMIT 1");
             $count_data = $loan_transaction['count'];
        if($count_data==1){
             $last_row = mysqli_fetch_array($loan_transaction['query']);
             $last_row_details = $last_row;
        $paid_installments = array_filter(explode(",", $last_row['month_name']));
        
        $last_installment = end($paid_installments);
       
          $last_installment_date  = new DateTime($last_row['created_at']);
           $last_installment_date = $last_installment_date->format('d-m-Y');
           
             }
        

        $response[] = array("value" => $row['loan_no'], "label" => $row['loan_no'], "last_installment" => $last_installment, "last_installment_date" => $last_installment_date, "data" => $row, "transect_details" => $last_row_details);
    }
    echo json_encode($response);
}


if (isset($_POST['details_account_info'])) {
    $fine_list = array();
    $installment_fine_check = manual_query("SELECT * FROM settings WHERE s_category='Installment_Fine'");
    while ($installment_fine_res = mysqli_fetch_assoc($installment_fine_check['query'])) {
        $fine_list[$installment_fine_res['s_name']]= $installment_fine_res['s_value'];
    }



    $search = $_POST['details_account_info'];
    // $result = single_condition_select("accounts", "member_id", $search);
    $response = array();
    $response['transection'] = array();
    // $response['currentBalance'] = 0;
    $response['error'] = "";

    $account_type = isset($_POST['account_search_type']) ? $_POST['account_search_type'] : "";

    $accounts_conditions = "";
    $loop_first = 1;
    if (is_array($account_type)) {
        foreach ($account_type as $key => $value) {
            if ($loop_first == 1) {
                $accounts_conditions .= " AND (account_type='{$value}'";
            } else {
                $accounts_conditions .= " OR account_type='{$value}'";
            }
            $loop_first++;
        }
    }
    if ($loop_first > 1) {
        $accounts_conditions .= ")";
    }


    $result = manual_query("SELECT * FROM `accounts` WHERE member_id ='$search' $accounts_conditions");

    $get_member_info = manual_query("SELECT * FROM members WHERE id='{$search}' ORDER BY id DESC LIMIT 1");
    $account_holder_result = mysqli_fetch_assoc($get_member_info['query']);
    $response['members_info'] = $account_holder_result;
    $response['member_id'] = $search;

    if ($result['count'] > 0) {
        while ($row = mysqli_fetch_assoc($result['query'])) {
            # code...
            // $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
            // $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
            // $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
            // $transection_query = mysqli_fetch_assoc($row_of_transection['query']);
            $response[$row['account_type']] = $row;
            // if ($row['account_type'] == "Loan") {
            //     // $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
            //     $row_of_transection = manual_query("SELECT * FROM transections WHERE account_no='{$row['id']}' AND installment_no > 0 ORDER BY id DESC LIMIT 1");
            //     $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
            //     $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
            //     $transection_query = mysqli_fetch_assoc($row_of_transection['query']);

            //     $total_installment = explode(" ", $row['payment_type']);
            //     $response['total_installment'] = $total_installment[0];
            // } else {
            // $row_of_transection = single_condition_sort("transections_details", "account_id", $row['id'], "id", "DESC", 1);
            $row_of_transection = manual_query("SELECT * FROM transections_details WHERE account_id='{$row['id']}' AND month_name !='' ORDER BY id DESC LIMIT 1");
            $row_last_transect_res = mysqli_fetch_assoc($row_of_transection['query']);

            $explode_months = explode(",", $row_last_transect_res['month_name']);
            $eleminate_last_months = array_pop($explode_months);
            $last_paid_months = end($explode_months);
            $response[$row['account_type']]['last_paid_month'] = isset($last_paid_months) ? $last_paid_months : "No record found";
            $response[$row['account_type']]['due_months'] = 0;
            if ($response[$row['account_type']]['last_paid_month'] != "No record found") {
                $ts1 = strtotime($response[$row['account_type']]['last_paid_month'].'-1');
                $ts2 = strtotime("$today");
                // $ts2 = strtotime($datetime);
                
                $response['show_time_passed'] = "";
                
                // $response['open_date_for_cal'] = $row['opening_date'];
                // $response['datetime_now'] = $datetime;
                if ($ts1 < $ts2) {
                    // $year1 = date('Y', $ts1);
                    // $year2 = date('Y', $ts2);

                    // $month1 = date('m', $ts1);
                    // $month2 = date('m', $ts2);

                    // $response['due_payment_month'] = (($year2 - $year1) * 12) + ($month2 - $month1);
                    $datetime1 = date("Y-m-d", $ts1);
                    $datetime1 = date_create($datetime1);
                    $datetime2 = date("Y-m-d", $ts2);
                    $datetime2 = date_create($datetime2);

                    $interval = date_diff($datetime1, $datetime2);

                    // echo $month = $interval->format("%m.%d");
                    // $response['due_payment_month'] =  $interval->format("%m.%d");            
                    $total_year_passed =  $interval->format("%y") * 12;
                    $total_month_passed =  $interval->format("%m.%d") + $total_year_passed;
                    $response['show_time_passed'] = $interval->format("%y Year %m Month %d Days");
                    // $response['check_date'] = 
                    $response[$row['account_type']]['due_months'] = $interval->format("%m");
                } else {
                    // $response['due_payment_month'] = 0;
                    $total_month_passed =  0;
                }
            } 
            $fine_amount = isset($fine_list[$row['account_type']])?$fine_list[$row['account_type']]:0;
            $response[$row['account_type']]['due_amount'] = 0;
            if($response[$row['account_type']]['due_months'] > 0){
                $response[$row['account_type']]['due_amount'] = $fine_amount;
            }
            

            // $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
            $total_balance_sql = manual_query("SELECT COALESCE(SUM(CASE WHEN (cash_in-cash_out) THEN (cash_in-cash_out) ELSE 0 END), 0) AS t_balance FROM transections_details WHERE account_id='{$row['id']}'");
            if ($total_balance_sql['count'] > 0) {
                $total_balance_sql_res = mysqli_fetch_assoc($total_balance_sql['query']);
                $response[$row['account_type']]['currentBalance'] = $total_balance_sql_res['t_balance'];
            }
        }
        echo json_encode($response);
    } else {
        $response['error'] = "<div class='alert alert-danger'>Account Not found</div>";
        echo json_encode($response);
    }
}







################################ OLD STUFF #######################
if (isset($_POST['checkuser'])) {
    $message = array();
    $value = $_POST['checkuser'];
    $checkuser = single_condition_select('users', 'username', $value);
    $count = $checkuser['count'];
    if ($count > 0) {
        $message['exist'] = "<span class='text-danger'>Already taken</span>";
    } else {
        $message['available'] = "<span class='text-success'>Username Available</span>";
    }
    echo json_encode($message);
}

if (isset($_POST['searchrefer'])) {
    $search = $_POST['searchrefer'];
    $response = array();
    $data = search_by_two_column_value("staffs", "name", $search, "staffid", $search);
    while ($row = mysqli_fetch_array($data['query'])) {
        $image = isset($row['staff_photo']) && file_exists("../" . $row['staff_photo']) ? $row['staff_photo'] : 'assets/images/img/demo.jpg';
        $response[] = array("value" => $row['staffid'], "label" => $row['name'], "image" => $image);
    }
    echo json_encode($response);
}

if (isset($_POST['searchmember'])) {
    $search = $_POST['searchmember'];
    $result = search_by_two_column_value("members", "name", $search, "id", $search);
    $response = array();
    $data = array();
    while ($row = mysqli_fetch_array($result['query'])) {
        $data['image'] = isset($row['member_photo']) && file_exists("../" . $row['member_photo']) ? $row['member_photo'] : 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];
        $data['branch'] = $row['office'];
        $data['center'] = $row['branch'];
        $oldaccounts = double_condition_select("account_create", "member_id", $row['id'], "account_type", "savings");
        $data['savings'] = "";
        while ($savinfo = mysqli_fetch_array($oldaccounts['query'])) {
            $data['savings'] .= " <a href='index.php?action=account_info&id={$savinfo['id']}'>{$savinfo['id']}</a>, ";
        }
        $olddeposit = double_condition_select("account_create", "member_id", $row['id'], "account_type", "deposit");
        $data['deposit'] = "";
        while ($deposit = mysqli_fetch_assoc($olddeposit['query'])) {
            $data['deposit'] .= " <a href='index.php?action=account_info&id={$deposit['id']}'>{$deposit['id']}</a>, ";
        }
        $oldlaon = double_condition_select("account_create", "member_id", $row['id'], "account_type", "laon");
        $data['laon'] = "";
        while ($laon = mysqli_fetch_assoc($oldlaon['query'])) {
            $data['laon'] .= " <a href='index.php?action=account_info&id={$laon['id']}'>{$laon['id']}</a>, ";
        }


        $response[] = array("value" => $row['id'], "label" => $row['name'], "data" => $data);
    }
    echo json_encode($response);
}
//Payment page member information
if (isset($_POST['searchmember_4_pay'])) {
    $search = $_POST['searchmember_4_pay'];
    if ($ac_type == "admin") {
        $result = search_by_two_column_value("members", "name", $search, "id", $search);
    } elseif ($user_other_info['office_id'] > 0 &&  $user_other_info['branch_id'] > 0) {
        $result = manual_query("SELECT * FROM members WHERE (name like '%$search%' OR id like '%$search%' OR mobile LIKE '%$search%') AND branch='{$user_other_info['branch_id']}'");
    }
    $response = array();
    $data = array();
    while ($row = mysqli_fetch_assoc($result['query'])) {
        $data['image'] = isset($row['member_photo']) && file_exists("../" . $row['member_photo']) ? $row['member_photo'] : 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];
        //Office info
        $office_sql = single_condition_select("office", "id", $row['office']);
        $office_res = mysqli_fetch_assoc($office_sql['query']);
        $data['branch'] = $office_res['name'];
        $data['branch_id'] = $office_res['id'];
        //Branch info
        $branch_sql = single_condition_select("branch", 'id', $row['branch']);
        $branch_res = mysqli_fetch_assoc($branch_sql['query']);
        $data['center'] = $branch_res['branch_name'];
        $data['center_id'] = $branch_res['id'];
        // $oldaccounts = double_condition_select("account_create", "member_id", $row['id'], "account_type", "savings");
        $oldaccounts = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['savings'] = "";
        $data['option'] = "<option value=''>Select account no</option>";
        while ($savinfo = mysqli_fetch_assoc($oldaccounts['query'])) {
            $data['savings'] .= " <a target='_blank' href='index.php?action=account_info&id={$savinfo['id']}' class='btn btn-dropbox btn-sm btn-rounded'>{$savinfo['id']}</a>&nbsp; ";
            $data['option'] .= "<option value='{$savinfo['id']}'>{$savinfo['account_no']}</option>";
        }
        // $olddeposit = double_condition_select("account_create", "member_id", $row['id'], "account_type", "deposit");
        $olddeposit = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['deposit'] = "";
        while ($deposit = mysqli_fetch_assoc($olddeposit['query'])) {
            $data['deposit'] .= " <a target='_blank' href='index.php?action=deposit_status&deposit_id={$deposit['id']}' class='btn btn-info btn-sm btn-rounded'>{$deposit['id']}</a>&nbsp; ";
            // $data['option'] .= "<option value='{$deposit['id']}'>Depo - {$deposit['id']}</option>";
        }
        // $oldlaon = double_condition_select("account_create", "member_id", $row['id'], "account_type", "loan");
        $oldlaon = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'loan' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['loan'] = "";
        while ($loan = mysqli_fetch_assoc($oldlaon['query'])) {
            // $data['loan'] .= "<a target='_blank' href='index.php?action=account_info&id={$loan['id']}' class='btn btn-info btn-sm btn-rounded'>{$loan['id']}</a>&nbsp; <a target='_blank' href='index.php?action=loan_status&loan_id={$loan['id']}' class='btn btn-info btn-sm btn-rounded'>Close This</a>&nbsp; ";
            $data['loan'] .= "<a target='_blank' href='index.php?action=loan_status&loan_id={$loan['id']}' class='btn btn-info btn-sm btn-rounded'>{$loan['id']}</a>&nbsp; ";
            $data['option'] .= "<option value='{$loan['id']}'>{$loan['account_no']}</option>";
        }


        $response[] = array("value" => $row['id'], "label" => $row['name'], "data" => $data);
    }
    echo json_encode($response);
}

//Account information for payment
if (isset($_POST['account_info_4_pay'])) {
    $search = $_POST['account_info_4_pay'];
    $result = single_condition_select("account_create", "id", $search);
    $response = array();
    $response['transection'] = array();
    $response['error'] = "";
    if ($result['count'] > 0) {
        $row = mysqli_fetch_assoc($result['query']);
        // $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
        // $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
        // $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
        // $transection_query = mysqli_fetch_assoc($row_of_transection['query']);


        $response['success'] = $row;
        if ($row['account_type'] == "loan") {
            // $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
            $row_of_transection = manual_query("SELECT * FROM transections WHERE account_no='{$row['id']}' AND installment_no > 0 ORDER BY id DESC LIMIT 1");
            $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
            $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
            $transection_query = mysqli_fetch_assoc($row_of_transection['query']);

            $total_installment = explode(" ", $row['payment_type']);
            $response['total_installment'] = $total_installment[0];
        } else {
            $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
            $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
            $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
            $transection_query = mysqli_fetch_assoc($row_of_transection['query']);
            $response['total_installment'] = $no_of_transection_result['suminstallment_no'];
        }

        $response['transection'] = $transection_query;
        if ($row_of_transection['count'] > 0) {
            $time = explode(",", $transection_query['installment_time']);
            $last_time = end($time);

            $response['date_last_trn'] = $last_time;
            $response['date_last_trn_for_cal'] = $last_time;
        } else {
            $response['date_last_trn'] = "No Record Found";
            $response['date_last_trn_for_cal'] = $row['opening_date'];
        }
        //Fine Calculation
        // $ts1 = strtotime($response['date_last_trn_for_cal']);
        // $ts2 = strtotime($datetime);
        // if ($ts1 < $ts2) {
        $ts1 = strtotime($row['opening_date']);
        $ts2 = strtotime($datetime);
        $response['show_time_passed'] = "";
        // $response['open_date_for_cal'] = $row['opening_date'];
        // $response['datetime_now'] = $datetime;
        if ($ts1 < $ts2) {
            // $year1 = date('Y', $ts1);
            // $year2 = date('Y', $ts2);

            // $month1 = date('m', $ts1);
            // $month2 = date('m', $ts2);

            // $response['due_payment_month'] = (($year2 - $year1) * 12) + ($month2 - $month1);
            $datetime1 = date("Y-m-d", $ts1);
            $datetime1 = date_create($datetime1);
            $datetime2 = date("Y-m-d", $ts2);
            $datetime2 = date_create($datetime2);

            $interval = date_diff($datetime1, $datetime2);

            // echo $month = $interval->format("%m.%d");
            // $response['due_payment_month'] =  $interval->format("%m.%d");            
            $total_year_passed =  $interval->format("%y") * 12;
            $total_month_passed =  $interval->format("%m.%d") + $total_year_passed;
            $response['show_time_passed'] = $interval->format("%y Year %m Month %d Days");
            // $response['check_date'] = 
        } else {
            // $response['due_payment_month'] = 0;
            $total_month_passed =  0;
        }


        $response['transection_no'] = ($no_of_transection_result['suminstallment_no'] == "") ? 0 : $no_of_transection_result['suminstallment_no'];
        if ($total_month_passed >  $response['transection_no']) {
            $response['due_payment_month'] = $total_month_passed - $response['transection_no'];
        } else {
            $response['due_payment_month'] = 0;
        }
        $response['total_month_passed'] = $total_month_passed;
        echo json_encode($response);
    } else {
        $response['error'] = "<div class='alert alert-danger'>Account Not found</div>";
        echo json_encode($response);
    }
    /*
    while ($row = mysqli_fetch_array($result['query'])){
        $data['image'] = isset($row['member_photo']) && file_exists("../".$row['member_photo']) ? $row['member_photo']: 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];
        $data['branch'] = $row['office'];
        $data['center'] = $row['branch'];
        
        $oldaccounts = double_condition_select("account_create", "member_id", $row['id'], "account_type", "savings");
        $data['savings'] = "";
        $data['option'] = "<option value=''>Select account no</option>";
        while($savinfo = mysqli_fetch_array($oldaccounts['query'])){
            $data['savings'] .= " <a href='index.php?action=account_info&id={$savinfo['id']}'>{$savinfo['id']}</a>, ";
            $data['option'] .= "<option value='{$savinfo['id']}'>Saving - {$savinfo['id']}</option>";
        }

        $response[] = array("value"=>$row['id'],"label"=>$row['name'],"data"=>$data);
        
    }  */
}

//Search Staff For Payment
if (isset($_POST['searchstaff_4_pay'])) {
    $search = $_POST['searchstaff_4_pay'];
    $result = search_by_two_column_value("staffs", "name", $search, "mobile", $search);
    $response = array();
    while ($row = mysqli_fetch_array($result['query'])) {
        $response[] = array("value" => $row['name'], "label" => $row['name'], "data" => $row['staffid']);
    }
    echo json_encode($response);
}

//Settings Main category
if (isset($_POST['search_setting_type'])) {
    $search = $_POST['search_setting_type'];
    $result = manual_query("SELECT s_category FROM settings WHERE s_category like '%" . $search . "%' GROUP BY s_category");

    $response = array();
    while ($row = mysqli_fetch_assoc($result['query'])) {
        $response[] = array("value" => $row['s_category'], "label" => $row['s_category'], "data" => $row['s_category']);
    }
    echo json_encode($response);
}

//Show Loan Application Detils
if (isset($_POST['show_loan_application_info'])) {
    $search = $_POST['show_loan_application_info'];
    $result = manual_query("SELECT * FROM applications WHERE id =$search");

    $response = array();
    $row = mysqli_fetch_assoc($result['query']);
    $staff_sql = single_condition_select("staffs", "staffid", $row['staff']);
    $staff_res = mysqli_fetch_assoc($staff_sql['query']);
    $row['staff_name'] = $staff_res['name'];
    $member_sql = single_condition_select("members", "id", $row['member_id']);
    $member_res = mysqli_fetch_assoc($member_sql['query']);
    // $status_sql = single_condition_select("applications_status", "application_id", $search);
    $status_sql = manual_query("SELECT `applications_status`.*, `users`.`username` FROM `applications_status` LEFT JOIN `users` ON `applications_status`.`created_by` = `users`.`userid` WHERE `applications_status`.`application_id`='$search'  ORDER BY `applications_status`.`id` DESC");
    $member_refer_sql = single_condition_select("members", "id", $row['member_refer']);
    $member_refer_res = mysqli_fetch_assoc($member_refer_sql['query']);
    $row['refer_name'] = $member_refer_res['name'];
    $row['refer_member_loan_status'] = "<i class='fa fa-check text-success' aria-hidden='true'></i>";
    $member_refer_loan_sql = manual_query("SELECT * FROM account_create WHERE member_id='{$row['member_refer']}' AND account_type='loan' AND status='active'");
    if ($member_refer_loan_sql['count'] > 0) {
        $member_refer_loan_res = mysqli_fetch_assoc($member_refer_loan_sql['query']);
        $row['refer_member_loan_status'] = "<i class='fa fa-check text-danger' aria-hidden='true'>{$member_refer_loan_res['account_no']}</i>";
    }
    $row['status_history'] = "";
    $row['member_name'] = $member_res['name'];
    $row['member_mobile'] = $member_res['mobile'];
    $row['photos'] = "";
    if ($row['documents'] != "") {
        $images = explode(",", $row['documents']);
        $images_no = count($images);
        for ($i = 0; $i < $images_no - 1; $i++) {
            $row['photos'] .= "<img src='{$images[$i]}' alt='' srcset='' height='60px' width='50px' class='modal_image_item pointer'>&nbsp;";
        }
    }
    $i = 1;
    while ($status_history_res = mysqli_fetch_assoc($status_sql['query'])) {
        $row['status_history'] .= "<tr><td>$i</td><td>{$status_history_res['created_at']}</td><td>{$status_history_res['username']}</td><td>{$status_history_res['status']}</td><td>{$status_history_res['info']}&nbsp; {$status_history_res['appoint_time']}</td></tr>";
        $i++;
    }
    // $response[] = array("value" => $row['s_category'], "label" => $row['s_category'], "data" => $row['s_category']);
    echo json_encode($row);
}
//Show Loan Application Status Detils Only
if (isset($_POST['show_loan_application_status_info'])) {
    $search = $_POST['show_loan_application_status_info'];
    $result = manual_query("SELECT * FROM applications WHERE id =$search");

    $row = array();
    $response = mysqli_fetch_assoc($result['query']);
    $row['status_history'] = "";
    $row['error_msg'] = "";
    if ($response['created_by'] == $uid || $ac_type == "admin") {
        $status_sql = manual_query("SELECT `applications_status`.*, `users`.`username` FROM `applications_status` LEFT JOIN `users` ON `applications_status`.`created_by` = `users`.`userid` WHERE `applications_status`.`application_id`=$search ORDER BY `applications_status`.`id` DESC");

        $i = 1;
        while ($status_history_res = mysqli_fetch_assoc($status_sql['query'])) {
            $row['status_history'] .= "<tr><td>$i</td><td>{$status_history_res['created_at']}</td><td>{$status_history_res['username']}</td><td>{$status_history_res['status']}</td><td>{$status_history_res['info']}&nbsp; {$status_history_res['appoint_time']}</td></tr>";
            $i++;
        }
    } else {
        $row['error_msg'] = "<div class='alert alert-danger'>Sorry application Number not Found</div>";
    }
    // $response[] = array("value" => $row['s_category'], "label" => $row['s_category'], "data" => $row['s_category']);
    echo json_encode($row);
}
//Show Loan Application Status Detils Only
if (isset($_POST['branch_info'])) {
    $branch_id = $_POST['branch_info'];
    $result = manual_query("SELECT * FROM branch WHERE id =$branch_id");

    $response = array();
    $row = mysqli_fetch_assoc($result['query']);
    $branch_ac_sql = manual_query("SELECT * FROM branch_account WHERE branch_id = '$branch_id'");
    $response['cash']['status'] = "editable";
    $response['cash']['ac_number'] = "";
    $response['bkash']['status'] = "editable";
    $response['bkash']['ac_number'] = "";
    $response['nagad']['status'] = "editable";
    $response['nagad']['ac_number'] = "";
    $response['bank']['status'] = "editable";
    $response['bank']['ac_number'] = "";
    while ($acc_res = mysqli_fetch_assoc($branch_ac_sql['query'])) {
        $starting_sql = manual_query("SELECT *, COUNT(*) as total_row FROM `branch_transection` WHERE ac_id = '{$acc_res['id']}' ORDER BY id ASC");
        $starting_res = mysqli_fetch_assoc($starting_sql['query']);
        if ($acc_res['ac_type'] == "cash") {
            if ($starting_res['total_row'] > 1) {
                $response['cash']['status'] = "readonly";
            } else {
                $response['cash']['starting_balance'] = $starting_res['earnings'];
            }
            $response['cash']['ac_number'] = $acc_res['ac_number'];
        }
        if ($acc_res['ac_type'] == "bkash") {
            if ($starting_res['total_row'] > 1) {
                $response['bkash']['status'] = "readonly";
            } else {
                $response['bkash']['starting_balance'] = $starting_res['earnings'];
            }
            $response['bkash']['ac_number'] = $acc_res['ac_number'];
            $response['bkash']['current_balance'] = $acc_res['current_balance'];
        }
        if ($acc_res['ac_type'] == "nagad") {
            if ($starting_res['total_row'] > 1) {
                $response['nagad']['status'] = "readonly";
            } else {
                $response['nagad']['starting_balance'] = $starting_res['earnings'];
            }
            $response['nagad']['ac_number'] = $acc_res['ac_number'];
            $response['nagad']['current_balance'] = $acc_res['current_balance'];
        }
        if ($acc_res['ac_type'] == "bank") {
            if ($starting_res['total_row'] > 1) {
                $response['bank']['status'] = "readonly";
            } else {
                $response['bank']['starting_balance'] = $starting_res['earnings'];
            }
            $response['bank']['ac_number'] = $acc_res['ac_number'];
            $response['bank']['current_balance'] = $acc_res['current_balance'];
        }
    }
    $response['branch_balance'] = $row['current_balance'];
    echo json_encode($response);
}

//Loan Applicaiotn page member information
if (isset($_POST['searchmember_4_refer'])) {
    $user_info = single_condition_select("users", "userid", $uid);
    $user_res = mysqli_fetch_assoc($user_info['query']);
    $loan_member = isset($_POST["loan_member_id"]) ? $_POST["loan_member_id"] : "";
    $branch = isset($_POST["branch"]) ? $_POST["branch"] : "";
    $search = $_POST['searchmember_4_refer'];
    $branch_condition = "";
    // if ($ac_type == "staff") {
    // $result = manual_query("SELECT * FROM members WHERE id != '$loan_member' AND (name like '%" . $search . "%' OR id like '%" . $search . "%') AND branch='$branch'");
    // } elseif ($ac_type == "admin") {
    $result = manual_query("SELECT * FROM members WHERE id != '$loan_member' AND (name like '%" . $search . "%' OR id like '%" . $search . "%') LIMIT 5");
    // }
    // $result = search_by_two_column_value("members", "name", $search, "id", $search);
    // $result = manual_query("SELECT * FROM members WHERE id != '$loan_member' AND (name like '%" . $search . "%' OR id like '%" . $search . "%') AND branch='$branch'");
    $response = array();
    $data = array();
    while ($row = mysqli_fetch_assoc($result['query'])) {
        $data['image'] = isset($row['member_photo']) && file_exists("../" . $row['member_photo']) ? $row['member_photo'] : 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];


        $response[] = array("value" => $row['id'], "label" => $row['name'], "desc" => $row['mobile'], "data" => $data);
    }
    echo json_encode($response);
}

//Withdraw page member information
if (isset($_POST['searchmember_4_withdraw'])) {
    $search = $_POST['searchmember_4_withdraw'];
    $result = search_by_two_column_value("members", "name", $search, "id", $search);

    $response = array();
    $data = array();
    while ($row = mysqli_fetch_assoc($result['query'])) {
        $data['image'] = isset($row['member_photo']) && file_exists("../" . $row['member_photo']) ? $row['member_photo'] : 'assets/images/img/demo.jpg';
        $data['mobile'] = $row['mobile'];
        $data['branch'] = $row['office'];
        $data['center'] = $row['branch'];
        $oldaccounts = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['savings'] = "";
        $data['option'] = "<option value=''>Select account no</option>";
        while ($savinfo = mysqli_fetch_assoc($oldaccounts['query'])) {
            $data['savings'] .= " <a target='_blank' href='index.php?action=account_info&id={$savinfo['id']}' class='btn btn-dropbox btn-sm btn-rounded'>{$savinfo['id']}</a>&nbsp; ";
            $data['option'] .= "<option value='{$savinfo['id']}'>Saving - {$savinfo['id']}</option>";
        }
        $olddeposit = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['deposit'] = "";
        while ($deposit = mysqli_fetch_assoc($olddeposit['query'])) {
            $data['deposit'] .= " <a target='_blank' href='index.php?action=deposit_status&deposit_id={$deposit['id']}' class='btn btn-info btn-sm btn-rounded'>{$deposit['id']}</a>&nbsp; ";
            $data['option'] .= "<option value='{$deposit['id']}'>Depo - {$deposit['id']}</option>";
        }
        $oldlaon = manual_query("SELECT * FROM `account_create` WHERE `account_create`.`account_type` = 'loan' AND `account_create`.`status` = 'active' AND member_id = '{$row['id']}'");
        $data['loan'] = "";
        while ($loan = mysqli_fetch_assoc($oldlaon['query'])) {
            $data['loan'] .= "<a target='_blank' href='index.php?action=loan_status&loan_id={$loan['id']}' class='btn btn-info btn-sm btn-rounded'>{$loan['id']}</a>&nbsp; ";
            // $data['option'] .= "<option value='{$loan['id']}'>Loan - {$loan['id']}</option>";
        }


        $response[] = array("value" => $row['id'], "label" => $row['name'], "data" => $data);
    }
    echo json_encode($response);
}

//Account information for Withdraw
if (isset($_POST['account_info_4_withdraw'])) {
    $search = $_POST['account_info_4_withdraw'];
    $result = single_condition_select("account_create", "id", $search);

    $response = array();
    $response['transection'] = array();
    // $data = array();
    if ($result['count'] > 0) {
        $row = mysqli_fetch_assoc($result['query']);
        if ($row['account_type'] == "savings") {
            $withdraw_fine_sql = single_condition_select("settings", "s_category", "savings_withdraw_fine");
            $withdraw_fine_res = mysqli_fetch_assoc($withdraw_fine_sql['query']);
        }

        $row_of_transection = single_condition_sort("transections", "account_no", $row['id'], "id", "DESC", 1);
        // $no_of_transection = sum_coloumn_wher("transections", "installment_no", "account_no", $row['id']);
        //$no_of_transection = manual_query("SELECT SUM(total_tk - withdraw) AS total_available, SUM(installment_no) AS suminstallment_no FROM transections WHERE account_no='{$row['id']}' AND (payment_for ='savings' OR payment_for ='main_balance_withdraw')");
        $no_of_transection = manual_query("SELECT SUM(total_tk - withdraw) AS total_available, SUM(installment_no) AS suminstallment_no, SUM(fine) AS fine_deduct FROM transections WHERE account_no='{$row['id']}' AND (payment_for ='savings' OR payment_for ='main_balance_withdraw')");


        $no_of_transection_result = mysqli_fetch_assoc($no_of_transection['query']);
        $response['fine_deduct'] = $no_of_transection_result['fine_deduct'] ?? 0;
        $transection_query = mysqli_fetch_assoc($row_of_transection['query']);

        //Profit Check
        // $profit_sql = manual_query("SELECT SUM(profit_amount) as total_profit FROM account_profits WHERE ac_id='$search'");
        $profit_sql = manual_query("SELECT SUM(profit_received) as total_profit FROM account_profits WHERE ac_id='$search'");
        $profit_res = mysqli_fetch_assoc($profit_sql['query']);
        $response['total_profit'] = $profit_res['total_profit'];
        //Profit Withdraw
        $profit_withdraw_sql = manual_query("SELECT SUM(amount) as total_profit_withdraw FROM withdraw_profit WHERE account_no='$search' AND withdraw_type='profit_withdraw'");
        $profit_withdraw_res = mysqli_fetch_assoc($profit_withdraw_sql['query']);
        //Profit Fine Check 
        // $profit_fine_query = manual_query("SELECT ");
        $response['profit_withdraw'] = (float)$profit_withdraw_res['total_profit_withdraw'];
        $profit_payable = $response['total_profit'] - $response['profit_withdraw'] - $response['fine_deduct'];
        $response['profit_payable'] = number_format((float)$profit_payable, 3);


        $response['success'] = $row;

        //Withdraw Fine Calculation
        $datetime1 = new DateTime($row['opening_date']);
        $datetime2 = new DateTime($datetime);
        $interval = $datetime1->diff($datetime2);
        $response['total_year'] = $interval->format('%y');
        $response['total_month'] = $interval->format('%m');
        $response['total_month_passed'] = $interval->format('%m') + ($interval->format('%y') * 12);
        $response['total_days'] = $interval->format('%d');

        $date1 = $row['opening_date'];
        $date2 = $datetime;

        $ts1 = strtotime($date1);
        $ts2 = strtotime($date2);

        $year1 = date('Y', $ts1);
        $year2 = date('Y', $ts2);

        $month1 = date('m', $ts1);
        $month2 = date('m', $ts2);

        $response['total_month_passed'] = (($year2 - $year1) * 12) + ($month2 - $month1);

        if ($row['account_type'] == "deposit") {
            $response['total_installment'] = 0;
            $response['main_balance'] = (int)$row['basic_amount'];
            $response['total_time_ac'] = $row['payment_type'];
        } else {
            $response['total_installment'] = $no_of_transection_result['suminstallment_no'];
            // $response['main_balance'] = $no_of_transection_result['suminstallment_no'] * $row['basic_amount'];
            $response['main_balance'] = $no_of_transection_result['total_available'];
            $savings_minimum_time = single_condition_select("settings", "s_category", "savings_withdraw_fine");
            $savings_minimum_res = mysqli_fetch_assoc($savings_minimum_time['query']);
            $response['total_time_ac'] = $savings_minimum_res['s_value'] * 12;
        }

        $response['transection'] = $transection_query;
        if ($row_of_transection['count'] > 0) {
            $time = explode(",", $transection_query['installment_time']);
            $last_time = end($time);

            $response['date_last_trn'] = $last_time;
            $response['date_last_trn_for_cal'] = $last_time;
        } else {
            $response['date_last_trn'] = "No Record Found";
            $response['date_last_trn_for_cal'] = $row['opening_date'];
        }

        //Branch Accounts Information
        $branch_id = $row['branch'];
        $response['cash'] = 0;
        $response['bkash'] = 0;
        $response['nagad'] = 0;
        $response['bank'] = 0;
        $branch_ac_sql = single_condition_select("branch_account", "branch_id", $branch_id);
        while ($branch_ac_res = mysqli_fetch_assoc($branch_ac_sql['query'])) {
            if ($branch_ac_res['ac_type'] == "cash") {
                $response['cash'] = $branch_ac_res['current_balance'];
            }
            if ($branch_ac_res['ac_type'] == "bkash") {
                $response['bkash'] = $branch_ac_res['current_balance'];
            }
            if ($branch_ac_res['ac_type'] == "nagad") {
                $response['nagad'] = $branch_ac_res['current_balance'];
            }
            if ($branch_ac_res['ac_type'] == "bank") {
                $response['bank'] = $branch_ac_res['current_balance'];
            }
        }


        $response['transection_no'] = ($no_of_transection_result['suminstallment_no'] == "") ? 0 : $no_of_transection_result['suminstallment_no'];
        echo json_encode($response);
    } else {
        $response['error'] = "<div class='alert alert-danger'>Account Not found</div>";
        echo json_encode($response);
    }
}
//Account information for Withdraw
if (isset($_POST['branch_ac_info'])) {
    $branch_id = $_POST['branch_ac_info'];
    $result = single_condition_select("branch_account", "branch_id", $branch_id);

    $response = array();
    if ($result['count'] > 0) {
        $response['cash'] = 0;
        $response['bkash'] = 0;
        $response['nagad'] = 0;
        $response['bank'] = 0;
        while ($row = mysqli_fetch_assoc($result['query'])) {
            if ($row['ac_type'] == "cash") {
                $response['cash'] = $row['current_balance'];
            }
            if ($row['ac_type'] == "bkash") {
                $response['bkash'] = $row['current_balance'];
            }
            if ($row['ac_type'] == "nagad") {
                $response['nagad'] = $row['current_balance'];
            }
            if ($row['ac_type'] == "bank") {
                $response['bank'] = $row['current_balance'];
            }
        }
        echo json_encode($response);
    } else {
        $response['error'] = "<div class='alert alert-danger'>Branch Account Info Not Found</div>";
        echo json_encode($response);
    }
}
//SMS COUNT
if (isset($_POST['message_count'])) {
    $search = $_POST['message_count'];
    $response = array();
    $charecters = strlen($search);
    $words = explode(" ", $search);
    $sms_count = ceil($charecters / 160);
    $max_char_set = $sms_count * 160;
    $response['char'] = "$charecters /$max_char_set- $sms_count";
    $response['word'] = count($words);
    $response['sms'] = $sms_count;
    $response['charecter'] = $charecters;

    echo json_encode($response);
}

//Senet Member mobile Verification Code
if (isset($_POST['verify_member_mobile'])) {
    $member_id = $_POST['verify_member_mobile'];
    $response = array();
    $member_sql = single_condition_select("members", "id", $member_id);
    if ($member_sql['count'] > 0) {
        $row = mysqli_fetch_assoc($member_sql['query']);
        $mobile_num = $row['mobile'];
        $rand = rand(111111, 999999);
        $message = "Your Mobile verification code is $rand";
        $sent_code = sms_to_member(array($mobile_num), $message);
        if (isset($sent_code['success'])) {
            $update_code = updatethis(array("id", $member_id), array("verify_token" => $rand), "members");
            $response['msg'] = "<div class='alert alert-success mt-2'>Verification code Sent successfully</div>";
        } else {
            $response['msg'] = "<div class='alert alert-danger mt-2'>{$sent_code['error']}</div>";
        }
    } else {
        $response['msg'] = "<div class='alert alert-danger mt-2'>Member not Found</div>";
    }
    echo json_encode($response);
}

//Sent Staff mobile Verification Code
if (isset($_POST['verify_staff_mobile'])) {
    $member_id = $_POST['verify_staff_mobile'];
    $response = array();
    $member_sql = single_condition_select("staffs", "staffid", $member_id);
    if ($member_sql['count'] > 0) {
        $row = mysqli_fetch_assoc($member_sql['query']);
        $mobile_num = $row['mobile'];
        $rand = rand(111111, 999999);
        $message = "Your shareforcure.com OTP code is $rand";
        $sent_code = sms_to_member(array($mobile_num), $message);
        if (isset($sent_code['success'])) {
            $update_code = updatethis(array("staffid", $member_id), array("verify_token" => $rand), "staffs");
            $response['msg'] = "<div class='alert alert-success mt-2'>Verification code Sent successfully</div>";
        } else {
            $response['msg'] = "<div class='alert alert-danger mt-2'>{$sent_code['error']}</div>";
        }
    } else {
        $response['msg'] = "<div class='alert alert-danger mt-2'>Staff not Found</div>";
    }
    echo json_encode($response);
}

//Download Transections
if (isset($_POST['download_transection'])) {
    $message = array();
    // if ($ac_type != "admin") {
    //     $message['error'] = "<div class='alert alert-danger'>Sorry You Have no Parmission to delete this</div>";
    // } else {
    $transection_id = $_POST['download_transection'];
    $transect_download_sql = single_condition_select("transections", "id", $transection_id);
    if ($transect_download_sql['count'] == 1) {

        $transect_res = mysqli_fetch_assoc($transect_download_sql['query']);
        if ($transect_res['payment_for'] == "New Savings") {
            $message['error'] = "<div class='alert alert-danger'>No Transection</div>";
        } else {
            $account_details_sql = single_condition_select("account_create", "account_no", $transect_res['account_no_full']);

            $message['name'] = "Not Found";
            $message['branch_name'] = "Branch Name";
            $branch_details_sql = single_condition_select("branch", "id", $transect_res['branch_id']);
            if ($branch_details_sql['count'] == 1) {
                $branch_res = mysqli_fetch_assoc($branch_details_sql['query']);
                $message['branch_name'] = $branch_res['branch_name'];
            }
            if ($account_details_sql['count'] == 1) {
                $account_details_res = mysqli_fetch_assoc($account_details_sql['query']);
                $member_id = $account_details_res['member_id'];
                $member_sql = single_condition_select('members', "id", $member_id);
                if ($member_sql['count'] == 1) {
                    $member_res = mysqli_fetch_assoc($member_sql['query']);
                    $message['name'] = $member_res['name'];
                }
            }

            // $message['transect_res'] = $transect_res;
            $message['ac_no'] = $transect_res['account_no_full'];
            $message['title'] = $transect_res['payment_for'];
            $message['payment_type'] = ($transect_res['withdraw'] > 0) ? "Withdraw" : "Deposit";
            $message['payment_amount'] = ($transect_res['withdraw'] > 0) ? $transect_res['withdraw'] : $transect_res['total_tk'];
            $message['transection_id'] = $transect_res['id'];
            $message['date'] = $transect_res['created_at'];
            $message['note'] = $transect_res['short_details'];

            // $taransect_branch_sql = double_condition_select("branch_transection", "ref_table", "transections", "ref_id", $transect_res['id']);
            // while ($transect_branch_res = mysqli_fetch_assoc($taransect_branch_sql['query'])) {

            //     $message['branch_transect_res'][]= $transect_branch_res;
            // }
            $message['success'] = "<div class='alert alert-success'>Downloaded Successfully</div>";
        }
    } else {
        $message['error'] = "<div class='alert alert-danger'>Transection not found</div>";
    }
    // }
    echo json_encode($message);
    exit;
}

//Delete Transections
if (isset($_POST['delete_transection'])) {
    $message = array();
    if ($ac_type != "admin") {
        $message['error'] = "<div class='alert alert-danger'>Sorry You Have no Parmission to delete this</div>";
    } else {
        $deleted_id = $_POST['delete_transection'];
        $transect_delete_sql = single_condition_select("transections", "id", $deleted_id);
        if ($transect_delete_sql['count'] == 1) {

            $transect_res = mysqli_fetch_assoc($transect_delete_sql['query']);
            if ($transect_res['payment_for'] == "New loan") {
                $message['error'] = "<div class='alert alert-danger'>New Loan Can't Be deleted</div>";
            } elseif ($transect_res['payment_for'] == "deposit") {
                $message['error'] = "<div class='alert alert-danger'>Deposit Can't Be deleted</div>";
            } elseif ($transect_res['payment_for'] == "Office Transection") {
                $message['error'] = "<div class='alert alert-danger'>Office Transection Can't Be deleted</div>";
            } elseif ($transect_res['payment_for'] == "Voucher") {
                $message['error'] = "<div class='alert alert-danger'>Voucher Can't Be deleted</div>";
            } elseif ($transect_res['payment_for'] == "New Account") {
                $message['error'] = "<div class='alert alert-danger'>New Account Can't Be deleted</div>";
            } else {
                deletedata("transections", $deleted_id);

                $taransect_branch_sql = double_condition_select("branch_transection", "ref_table", "transections", "ref_id", $transect_res['id']);

                while ($transect_branch_res = mysqli_fetch_assoc($taransect_branch_sql['query'])) {
                    deletedata("branch_transection", $transect_branch_res['id']);
                }
                $message['success'] = "<div class='alert alert-success'>Deleted Successfully</div>";
                branch_balance_update($transect_res['branch_id']);
            }
        } else {
            $message['error'] = "<div class='alert alert-danger'>Transection not found</div>";
        }
    }
    echo json_encode($message);
    exit;
}
//Delete Loan Applications
if (isset($_POST['delete_loan_application_info'])) {
    $message = array();
    if ($ac_type != "admin") {
        $message['error'] = "<div class='alert alert-danger'>Sorry You Have no Parmission to delete this</div>";
    } else {
        $deleted_id = $_POST['delete_loan_application_info'];
        $transect_delete_sql = single_condition_select("applications", "id", $deleted_id);
        if ($transect_delete_sql['count'] == 1) {

            $transect_res = mysqli_fetch_assoc($transect_delete_sql['query']);
            if ($transect_res['status'] != "paid") {
                deletedata("applications", $deleted_id);

                $message['success'] = "<div class='alert alert-success'>Application Deleted Successfully</div>";
                // branch_balance_update($transect_res['branch_id']);
            } else {
                $message['error'] = "<div class='alert alert-danger'>This Loan Application paid already</div>";
            }
        } else {
            $message['error'] = "<div class='alert alert-danger'>Application not found</div>";
        }
    }
    echo json_encode($message);
    exit;
}

//Branch Balance transfer information 
if (isset($_POST['balance_transfer_branch_info'])) {
    $message = array();
    $message['depo'] = 0;
    $message['rece'] = 0;
    $message['error'] = "";
    if ($ac_type != "admin") {
        $message['error'] = "<div class='alert alert-danger'>Sorry You Have no Parmission to Check this</div>";
    } else {
        $branch_id = $_POST['balance_transfer_branch_info'];
        $branch_balance_sql = manual_query("SELECT COALESCE(SUM(deposit), 0) AS total_depo, COALESCE(SUM(withdraw), 0) AS total_withd FROM office_transections WHERE branch_id='$branch_id'");
        $branch_balance_res = mysqli_fetch_assoc($branch_balance_sql['query']);
        $message['depo'] = $branch_balance_res['total_depo'];
        $message['rece'] = $branch_balance_res['total_withd'];
    }
    echo json_encode($message);
    exit;
}
//Branch Balance transfer information 
if (isset($_POST['branch_office_ac_info'])) {
    $message = array();
    $message['cash'] = 0;
    $message['bkash'] = 0;
    $message['nagad'] = 0;
    $message['bank'] = 0;
    $message['error'] = "";
    $message['office_balance'] = 0;
    if ($ac_type != "admin") {
        $message['error'] = "<div class='alert alert-danger'>Sorry You Have no Parmission to Check this</div>";
    } else {
        $branch_id = $_POST['branch_office_ac_info'];
        $branch_ac_sql = single_condition_select("branch_account", "branch_id", $branch_id);

        $office_balance_status_sql = manual_query("SELECT SUM(deposit-withdraw) AS available_balance FROM `branch_expenses` WHERE `branch_id`= '$branch_id'");
        $office_balance_status_res = mysqli_fetch_assoc($office_balance_status_sql['query']);
        $message['office_balance'] = $office_balance_status_res['available_balance'];

        if ($branch_ac_sql['count'] > 0) {
            while ($branch_ac_res = mysqli_fetch_assoc($branch_ac_sql['query'])) {
                if ($branch_ac_res['ac_type'] == "cash") {
                    $message['cash'] = $branch_ac_res['current_balance'];
                }
                if ($branch_ac_res['ac_type'] == "bkash") {
                    $message['bkash'] = $branch_ac_res['current_balance'];
                }
                if ($branch_ac_res['ac_type'] == "nagad") {
                    $message['nagad'] = $branch_ac_res['current_balance'];
                }
                if ($branch_ac_res['ac_type'] == "bank") {
                    $message['bank'] = $branch_ac_res['current_balance'];
                }
            }
        } else {
            $message['error'] = "<div class='alert alert-danger'>Sorry Something Wrong</div>";
        }
        echo json_encode($message);
        exit;
    }
}
//Profit Distribution
if (isset($_POST['profit_distribute'])) {
    $message = array();
    $message['error'] = "Profit Not Distributed";

    // $update_loan_status = updatethis(array("id" => $loan_id), array("status" => "close"), "account_create");

    /*
    //Savings Part
    $savings_profit_sql = manual_query("SELECT `account_create`.*, COALESCE(SUM(`transections`.`total_tk`-`transections`.`fine`),0) AS total_savings FROM `account_create` LEFT JOIN `transections` ON `account_create`.`id`=`transections`.`account_no` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active' GROUP BY `account_create`.`id`");

    $total_savings_sql = manual_query("SELECT `account_create`.`account_type`, COALESCE(SUM(`transections`.`total_tk`-`transections`.`fine`),0) AS total_savings FROM `account_create` LEFT JOIN `transections` ON `account_create`.`id`=`transections`.`account_no` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active'");
    $total_savings_res = mysqli_fetch_assoc($total_savings_sql['query']);
    $total_savings = $total_savings_res['total_savings'];

    while ($savings_profit_res = mysqli_fetch_assoc($savings_profit_sql['query'])) {
        $ac_id_4profit = $savings_profit_res['id'];
        $ac_type_4profit = $savings_profit_res['account_type'];
        $ac_current_balance_4profit = $savings_profit_res['total_savings'];
        $profit_amount = number_format((($savings_amount / $total_savings) * $ac_current_balance_4profit), 2);
        $accounts_profit = array(
            "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
            "created_id" => $uid,
            "created_ip" => $ip,
            "profit_id" => $insert_profit['last_id'],
            "ac_id" => $ac_id_4profit,
            "ac_type" => $ac_type_4profit,
            "total_profit" => $savings_amount,
            "current_balance" => $ac_current_balance_4profit,
            "profit_amount" => $profit_amount,
        );
        $insert_savings = insert_data($conn, $accounts_profit, "account_profits");
    }
    //Deposite Part
    $total_deposite_sql = manual_query("SELECT `account_create`.`account_type`, SUM(`basic_amount`) AS total_deposit FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active'");
    $total_deposit_res = mysqli_fetch_assoc($total_deposite_sql['query']);
    $total_deposit = $total_deposit_res['total_deposit'];

    $deposit_profit_sql = manual_query("SELECT `account_create`.* FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active'");
    while ($deposit_profit_res = mysqli_fetch_assoc($deposit_profit_sql['query'])) {
        $ac_id_4profit = $deposit_profit_res['id'];
        $ac_type_4profit = $deposit_profit_res['account_type'];
        $ac_current_balance_4profit = $deposit_profit_res['basic_amount'];
        $profit_amount = number_format((($deposite_amount / $total_deposit) * $ac_current_balance_4profit), 2);
        $accounts_profit = array(
            "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
            "created_id" => $uid,
            "created_ip" => $ip,
            "profit_id" => $insert_profit['last_id'],
            "ac_id" => $ac_id_4profit,
            "ac_type" => $ac_type_4profit,
            "total_profit" => $deposite_amount,
            "current_balance" => $ac_current_balance_4profit,
            "profit_amount" => $profit_amount,
        );
        $insert_savings = insert_data($conn, $accounts_profit, "account_profits");
    }
    */
    echo json_encode($message);
    exit;
}
//Check Available Fine Balance For Withdraw
if (isset($_POST['available_fine_for_branch'])) {
    $branch_id = $_POST['available_fine_for_branch'];
    $balance = 0;
    if ($branch_id > 0) {
        $total_fine_sql = manual_query("SELECT COALESCE(SUM(fine_amount), 0) AS total_fine, COALESCE(SUM(fine_withdraw), 0) AS total_withdraw FROM `fine_collections` WHERE branch_id='$branch_id'");
        if ($total_fine_sql['count'] > 0) {
            $total_fine_res = mysqli_fetch_assoc($total_fine_sql['query']);
            $balance = $total_fine_res['total_fine'] - $total_fine_res['total_withdraw'];
        }
    }
    echo $balance;
    exit;
}
//Check Available Staff Commission For Withdraw
if (isset($_POST['available_staff_balance'])) {
    $staff_id = $_POST['available_staff_balance'];
    $balance = 0;
    if ($staff_id > 0) {
        $total_commission_sql = manual_query("SELECT COALESCE(SUM(earnings), 0) AS total_earnings, COALESCE(SUM(expense), 0) AS total_expense FROM `staff_transections` WHERE staff_id='$staff_id'");
        if ($total_commission_sql['count'] > 0) {
            $total_commission_res = mysqli_fetch_assoc($total_commission_sql['query']);
            $balance = $total_commission_res['total_earnings'] - $total_commission_res['total_expense'];
            $balance = number_format($balance, 0, ".", "");
        }
    }
    echo $balance;
    exit;
}

// profit percent for loan type
if (isset($_POST['loan_type']) && $_POST['loan_no'] != "") {
    
    $selected_loan_type = $_POST['loan_type'];
    $loan_no = $_POST['loan_no'];
    
$loan_account = manual_query("SELECT * FROM `loan_account` WHERE loan_type='$selected_loan_type' AND id='$loan_no'");
if ($loan_account['count'] == 1) {
            $profit_range = mysqli_fetch_assoc($loan_account['query']);
            $loan_holder_name = $profit_range['name'];
}

echo $profit_percent;

}

// loan no check
// Check existing account
if(isset($_POST['loan_no_search']) && $_POST['loan_type'] != ""){
    
    $check_loan_account = double_condition_select("loan_account", "loan_type", $_POST['loan_type'], "loan_no", $_POST['loan_no_search']);
//print_r($check_account);
if ($check_loan_account['count'] > 0 ) {
            $alert = "<span style='color:red;'>Already Exist</span>";
            
            
}else{
    $alert = "<span style='color:green;'>Available</span>";
}
//echo $alert;
echo json_encode($alert);

}

// Share Savings account check and suggestion
if (isset($_POST['account_no']) && $_POST['account_type'] != "") {
$type = $_POST['account_type'];
$account_no = $_POST['account_no'];
$check_account = manual_query("SELECT * FROM `accounts` WHERE account_type = '$type' AND account_no LIKE '%$account_no%'");

    $response = array();

    if (!empty($check_account['count']) && $check_account['count'] > 0) {
        
      while($row = mysqli_fetch_assoc($check_account['query'])){
          
    // account profit calculation
    $account_id = $row['id'];
    $profit = manual_query("SELECT *, SUM(increase) AS increase_total, SUM(decrease) AS decrease_total FROM `accounts_profit` WHERE ac_id = '$account_id'");
    
     $profit_row = mysqli_fetch_assoc($profit['query']);
     $increase = $profit_row['increase_total'];
     $decrease = $profit_row['decrease_total'];
     $profit_balance = (int)$increase - (int)$decrease;
     
    // array create for ajax
        $response[] = array(
            "value" => $row['account_no'], // what autocomplete will insert
            "label" => $row['account_no'] . " - " . $row['account_title'], // what user sees in dropdown
            "profit_balance" => $profit_balance,
            "data"  => $row // full row for your JS
        );
    }
}
    echo json_encode($response);
    exit;
}
