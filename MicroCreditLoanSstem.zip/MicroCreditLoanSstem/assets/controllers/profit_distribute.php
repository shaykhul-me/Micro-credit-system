<?php
include('../seassion.php');
if (isset($_POST['profit_title'])) {
    $profit_category = $_POST['profit_title'];
    $savings_pro_res = array();
    $refer_staff_arr = array();
    $ck_result = array();
    $profit_distribute_sql = manual_query("SELECT * FROM settings WHERE s_category='profit_distribute' OR s_category='referal_profit'");
    $institute_percent = 0;
    $deposite_percent = 0;
    $savings_percent = 0;
    $referal_savings_percent = 0;
    $total_savings_profit_paid = 0;
    $total_deposit_profit_paid = 0;

    $profit_title_search = single_condition_select("profits_title", "title", $profit_category);
    if ($profit_title_search['count'] > 0 || $profit_category == "") {
        echo "This Title Already Exist";
        exit;
    } else {


        while ($profit_distribute_res = mysqli_fetch_assoc($profit_distribute_sql['query'])) {
            if ($profit_distribute_res['s_name'] == "institute" && $profit_distribute_res['s_category'] == "profit_distribute") {
                $institute_percent = $profit_distribute_res['s_value'];
            }
            if ($profit_distribute_res['s_name'] == "deposit" && $profit_distribute_res['s_category'] == "profit_distribute") {
                $deposite_percent = $profit_distribute_res['s_value'];
            }
            if ($profit_distribute_res['s_name'] == "savings" && $profit_distribute_res['s_category'] == "profit_distribute") {
                $savings_percent = $profit_distribute_res['s_value'];
            }
            if ($profit_distribute_res['s_name'] == "savings" && $profit_distribute_res['s_category'] == "referal_profit") {
                $referal_savings_percent = $profit_distribute_res['s_value'];
            }
        }

        //Total Unpaid Profit Calculation
        // $unpaid_profit_sql = manual_query("SELECT COALESCE(SUM(deposit_amount),0) AS deposit_profit, COALESCE(SUM(savings_amount),0) AS savings_profit FROM `profits` WHERE status='unpaid'");
        // $unpaid_profit_res = mysqli_fetch_assoc($unpaid_profit_sql['query']);
        $total_profit = 0;
        $loan_staff_amount = 0;
        $unpaid_profit_sql = manual_query("SELECT * FROM `profits` WHERE status='unpaid'");
        while ($unpaid_profit_res = mysqli_fetch_assoc($unpaid_profit_sql['query'])) {
            $total_profit += $unpaid_profit_res['total_profit'];
            $loan_staff_amount += $unpaid_profit_res['staff_amount'];
        }
        $total_payable_profit = $total_profit - $loan_staff_amount;

        // $institute_amount = ($profit_cal * $institute_percent) / 100;
        // $deposite_amount = ($profit_cal * $deposite_percent) / 100;
        // $savings_amount = ($profit_cal * $savings_percent) / 100;
        // $deposite_amount = $unpaid_profit_res['deposit_profit'];
        // $savings_amount = $unpaid_profit_res['savings_profit'];
        // $deposite_amount = ceil($deposite_amount);
        // $savings_amount = ceil($savings_amount);
        // echo $deposite_amount."-".$savings_amount;
        // if (($deposite_amount + $savings_amount) > 0) {
        if (($total_payable_profit) > 0) {

            $sum_col_1 = 0;
            $sum_col_2 = 0;
            $sum_col_3 = 0;
            $i = 1;


            // Total Savings And Deposit
            // Savings Part

            $total_savings_sql =  manual_query("SELECT `account_create`.`account_type`, COALESCE(SUM(`transections`.`total_tk`),0) AS total_savings FROM `account_create` LEFT JOIN `transections` ON `account_create`.`id`=`transections`.`account_no` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active'");
            $total_savings_res = mysqli_fetch_assoc($total_savings_sql['query']);
            $total_savings = $total_savings_res['total_savings'];

            //Deposite Part
            $total_deposite_sql = manual_query("SELECT `account_create`.`account_type`, SUM(`basic_amount`) AS total_deposit FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active'");
            $total_deposit_res = mysqli_fetch_assoc($total_deposite_sql['query']);
            $total_deposit = $total_deposit_res['total_deposit'];



            $total_savings_and_deposite = $total_deposit + $total_savings;



            //Savings Part
            $savings_profit_sql = manual_query("SELECT `account_create`.*, COALESCE(SUM(`transections`.`total_tk`),0) AS total_savings FROM `account_create` LEFT JOIN `transections` ON `account_create`.`id`=`transections`.`account_no` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active' GROUP BY `account_create`.`id`");

            // $total_savings_sql =  manual_query("SELECT `account_create`.`account_type`, COALESCE(SUM(`transections`.`total_tk`),0) AS total_savings FROM `account_create` LEFT JOIN `transections` ON `account_create`.`id`=`transections`.`account_no` WHERE `account_create`.`account_type` = 'savings' AND `account_create`.`status` = 'active'");
            // $total_savings_res = mysqli_fetch_assoc($total_savings_sql['query']);
            // $total_savings = $total_savings_res['total_savings'];

            while ($savings_profit_res = mysqli_fetch_assoc($savings_profit_sql['query'])) {
                $ac_id_4profit = $savings_profit_res['id'];
                $ac_type_4profit = $savings_profit_res['account_type'];
                $ac_current_balance_4profit = $savings_profit_res['total_savings'];
                //Refer Staff ID
                $refer_id = $savings_profit_res['staff_ref']; //$refer_staff_arr
                $profit_amount = 0;
                $refer_profit = 0;
                $ac_profit = 0;
                if ($total_savings_and_deposite > 0 && $ac_current_balance_4profit > 0) {
                    // $profit_amount = number_format((($savings_amount / $total_savings) * $ac_current_balance_4profit), 2);

                    $profit_amount = number_format((($total_payable_profit / $total_savings_and_deposite) * $ac_current_balance_4profit), 2, '.', '');


                    $institute_profit = ($profit_amount * $institute_percent) / 100;

                    $ac_profit = $profit_amount - $institute_profit;


                    $refer_profit = ($ac_profit * $referal_savings_percent) / 100;

                    $ac_profit = $profit_amount - $refer_profit;

                    $total_savings_profit_paid += $ac_profit;


                    $accounts_profit = array(
                        "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_id" => $uid,
                        "created_ip" => $ip,
                        "branch_id" => $savings_profit_res['branch'],
                        "profit_code" => $profit_category,
                        "ac_id" => $savings_profit_res['id'],
                        "ac_no_full" => $savings_profit_res['account_no'],
                        "ac_type" => $ac_type_4profit,
                        "refer_id" => $savings_profit_res['staff_ref'],
                        "total_profit" => $total_payable_profit,
                        "total_deposit_savings" => $total_savings_and_deposite,
                        "current_balance" => $ac_current_balance_4profit,
                        "profit_amount" => $profit_amount,
                        "refer_amount" => $refer_profit,
                        "branch_amount" => $institute_profit,
                        "profit_received" => $ac_profit,
                        "profit_withdraw" => 0,
                        "status" => "",
                        "notes" => ""
                    );
                    $insert_savings = insert_data($conn, $accounts_profit, "account_profits");
                    $ck_result[] = $accounts_profit;



                    //Profit add in account
                    $profit_add_array = array(
                        "created_by" =>  $uid,
                        "created_at" =>   date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_ip" => $ip,
                        "account_no" => $savings_profit_res['id'],
                        "account_no_full" => $savings_profit_res['account_no'],
                        "basic_amount" => $savings_profit_res['basic_amount'],
                        "payment_for" => "Profit -" . $profit_category,
                        "installment_no" => 0,
                        "installment_time" => 0,
                        // "payment_type" => $payment_type,
                        // "payment_info" => $payment_info,
                        // "payment_photo" => $payment_photo,
                        // "fine" => $fine,
                        "total_tk" => $ac_profit,
                        "short_details" => "Profit",
                        // "profit" => $profit,
                        "status" => "paid",
                        "branch_id" => $savings_profit_res['branch']
                    );

                    $new_transection = insert_data($conn, $profit_add_array, "transections");
                    $new_transection_id = $new_transection['last_id'];

                    // refer amount goes to staff_transections
                    $my_ac_type = $savings_profit_res['account_type'];
                    $my_ac = $savings_profit_res['account_no'];
                    $ac_with_type = "$my_ac_type-$my_ac";
                    $refer_profit_array = array(
                        "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_by" => $uid,
                        "created_ip" => $ip,
                        "branch_id" => $savings_profit_res['branch'],
                        "transection_id" => $new_transection_id,
                        "staff_id" => $savings_profit_res['staff_ref'],
                        "short_details" => "Refer Amount",
                        "details" => $ac_with_type,
                        "earnings" => $refer_profit,

                    );
                    insert_data($conn, $refer_profit_array, "staff_transections");

                    $branch_commission_sql = array(
                        "created_id" =>  $uid,
                        "created_at" =>  date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_ip" => $ip,
                        "branch_id" => $savings_profit_res['branch'],
                        "transection_id" => $new_transection['last_id'],
                        "title" => "Profit Commisstion",
                        "info" => "Savings ID:" . $savings_profit_res['account_no'],
                        "deposit" => $institute_profit,
                    );
                    $branch_commission_res = insert_data($conn, $branch_commission_sql, "branch_expenses");


                    $i++;
                    $sum_col_1 += $profit_amount;
                    $sum_col_2 += $refer_profit;
                    $sum_col_3 += $ac_profit;
                }
            }

            //Deposite Part
            $total_deposite_sql = manual_query("SELECT `account_create`.`account_type`, SUM(`basic_amount`) AS total_deposit FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active'");
            $total_deposit_res = mysqli_fetch_assoc($total_deposite_sql['query']);
            $total_deposit = $total_deposit_res['total_deposit'];

            $deposit_profit_sql = manual_query("SELECT `account_create`.* FROM `account_create` WHERE `account_create`.`account_type` = 'deposit' AND `account_create`.`status` = 'active'");
            while ($deposit_profit_res = mysqli_fetch_assoc($deposit_profit_sql['query'])) {
                $ac_id_4profit = $deposit_profit_res['id'];
                $ac_type_4profit = $deposit_profit_res['account_type'];
                $ac_current_balance_4profit = $deposit_profit_res['basic_amount'];
                // $profit_amount = number_format((($deposite_amount / $total_deposit) * $ac_current_balance_4profit), 2);
                //Refer Staff ID
                $refer_id = $deposit_profit_res['staff_ref']; //$refer_staff_arr
                $profit_amount = 0;
                $refer_profit = 0;
                $ac_profit = 0;
                if ($total_savings_and_deposite > 0 && $ac_current_balance_4profit > 0) {
                    // $profit_amount = number_format((($deposite_amount / $total_deposit) * $ac_current_balance_4profit), 2);
                    $profit_amount = number_format((($total_payable_profit / $total_savings_and_deposite) * $ac_current_balance_4profit), 2, '.', '');


                    $institute_profit = ($profit_amount * $institute_percent) / 100;


                    $ac_profit = $profit_amount - $institute_profit;
                    $refer_profit = ($ac_profit * $referal_savings_percent) / 100;
                    $ac_profit = $ac_profit - $refer_profit;
                    $total_deposit_profit_paid += $ac_profit;


                    $accounts_profit = array(
                        "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_id" => $uid,
                        "created_ip" => $ip,
                        "branch_id" => $deposit_profit_res['branch'],
                        "profit_code" => $profit_category,
                        "ac_id" => $deposit_profit_res['id'],
                        "ac_no_full" => $deposit_profit_res['account_no'],
                        "ac_type" => $ac_type_4profit,
                        "refer_id" => $deposit_profit_res['staff_ref'],
                        "total_profit" => $total_payable_profit,
                        "total_deposit_savings" => $total_savings_and_deposite,
                        "current_balance" => $ac_current_balance_4profit,
                        "profit_amount" => $profit_amount,
                        "refer_amount" => $refer_profit,
                        "branch_amount" => $institute_profit,
                        "profit_received" => $ac_profit,
                        "profit_withdraw" => 0,
                        "status" => "",
                        "notes" => ""
                    );
                    $insert_savings = insert_data($conn, $accounts_profit, "account_profits");

                    //Profit add in account
                    $profit_add_array = array(
                        "created_by" =>  $uid,
                        "created_at" =>   date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_ip" => $ip,
                        "account_no" => $deposit_profit_res['id'],
                        "account_no_full" => $deposit_profit_res['account_no'],
                        "basic_amount" => $deposit_profit_res['basic_amount'],
                        "payment_for" => "Profit -" . $profit_category,
                        "installment_no" => 0,
                        "installment_time" => 0,
                        // "payment_type" => $payment_type,
                        // "payment_info" => $payment_info,
                        // "payment_photo" => $payment_photo,
                        // "fine" => $fine,
                        "total_tk" => $ac_profit,
                        "short_details" => $profit_category,
                        // "profit" => $profit,
                        "status" => "paid",
                        "branch_id" => $deposit_profit_res['branch']
                    );

                    $new_transection = insert_data($conn, $profit_add_array, "transections");
                    $new_transection_id = $new_transection['last_id'];

                    $ck_result[] = $profit_add_array;
                    // refer amount goes to staff_transections
                    $my_ac_type = $deposit_profit_res['account_type'];
                    $my_ac = $deposit_profit_res['account_no'];
                    $ac_with_type = "$my_ac_type-$my_ac";
                    $refer_profit_array = array(
                        "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_by" => $uid,
                        "created_ip" => $ip,
                        "branch_id" => $deposit_profit_res['branch'],
                        "transection_id" => $new_transection_id,
                        "staff_id" => $deposit_profit_res['staff_ref'],
                        "short_details" => "Refer Amount",
                        "details" => $ac_with_type,
                        "earnings" => $refer_profit,

                    );
                    insert_data($conn, $refer_profit_array, "staff_transections");

                    $i++;
                    $sum_col_1 += $profit_amount;
                    $sum_col_2 += $refer_profit;
                    $sum_col_3 += $ac_profit;

                    $branch_commission_sql = array(
                        "created_id" =>  $uid,
                        "created_at" =>  date("Y-m-d H:i:s", strtotime($datetime)),
                        "created_ip" => $ip,
                        "branch_id" => $deposit_profit_res['branch'],
                        "transection_id" => $new_transection['last_id'],
                        "title" => "Profit Commisstion",
                        "info" => "Deposit ID:" . $deposit_profit_res['account_no'],
                        "deposit" => $institute_profit,
                    );
                    $branch_commission_res = insert_data($conn, $branch_commission_sql, "branch_expenses");
                }
            };
            $title_array = array(
                "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                "created_id" => $uid,
                "created_ip" => $ip,
                "title" => $profit_category,
                "savings_amount" => $total_savings_profit_paid,
                "deposite_amount" => $total_deposit_profit_paid,
                "profits_range" => "",
                "details" => ""
            );
            $insert_profit_title = insert_data($conn, $title_array, "profits_title");
            $unpaid_profit_sql = manual_query("SELECT * FROM `profits` WHERE status='unpaid'");
            while ($unpaid_profit_update_res = mysqli_fetch_assoc($unpaid_profit_sql['query'])) {
                // $total_profit += $unpaid_profit_res['total_profit'];
                // $loan_staff_amount += $unpaid_profit_res['staff_amount'];
                $total_payable_profit = $unpaid_profit_update_res['total_profit'] - $unpaid_profit_update_res['staff_amount'];
                $institue_profit_amount = ($total_payable_profit * $institute_percent) / 100;
                $this_total_profit = $total_payable_profit- $institue_amount;
                // $institue_profit_amount = ($this_total_profit * $institute_percent) / 100;
                $deposit_and_savings_amount = ($this_total_profit - $institue_profit_amount) / 2;
                $update_array = array(
                    "status" => "paid",
                    "paid_note" => $profit_category,
                    "institute_amount" => $institue_profit_amount,
                    "deposit_amount" => $deposit_and_savings_amount,
                    "savings_amount" => $deposit_and_savings_amount,
                );

                updatethis(array("id" => $unpaid_profit_update_res['id']), $update_array, "profits");
            }

            // }
            // var_dump($ck_result);
            // foreach ($ck_result as $key => $value) {
            //     // var_dump($value);
            //     foreach ($value as $key2 => $value2) {
            //         echo $key2 . "=" . $value2;
            //         echo "<br>";
            //     }
            //     echo "<br><br>";
            // }
            echo "Success";
        } else {
            echo "No Profits Payable";
        }
    }
} elseif ($_POST['manual_profit_title']) {
    // $return_message = array("Success");
    $profit_category = $_POST['manual_profit_title'];
    $total_payable_profit = $_POST['total_payable_profit'];
    $total_savings_and_deposite = $_POST['total_savings_and_deposite'];
    $institute_percent = $_POST['institute_percent'];
    $total_institute_profits = $_POST['total_institute_profits'];
    parse_str($_POST['all_form_data'], $allFormDataArray);
    $institute_percent = 0;
    $deposite_percent = 0;
    $savings_percent = 0;
    $referal_savings_percent = 0;
    $total_savings_profit_paid = 0;
    $total_deposit_profit_paid = 0;
    // $return_message['request'] = $allFormDataArray;
    foreach ($allFormDataArray['account_id'] as $account_type => $all_account_details) {
        // $return_message['ac_type_ke'][] = $all_account_details;
        if ($account_type == "deposit") {
            foreach ($all_account_details as $account_id => $account_details) {
                $ac_type_4profit = $account_type;
                $accounts_profit = array(
                    "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_id" => $uid,
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "profit_code" => $profit_category,
                    "ac_id" => $account_id,
                    "ac_no_full" => $account_details['full_ac_number'],
                    "ac_type" => $ac_type_4profit,
                    "refer_id" => $account_details['staff_ref'],
                    "total_profit" => $total_payable_profit,
                    "total_deposit_savings" => $total_savings_and_deposite,
                    "current_balance" => $account_details['total_balance'],
                    "profit_amount" => $account_details['profit_amount'],
                    "refer_amount" => $account_details['refer_profit'],
                    "branch_amount" => $account_details['institute_profit'],
                    "profit_received" => $account_details['ac_profit'],
                    "profit_withdraw" => 0,
                    "status" => "",
                    "notes" => ""
                );
                $insert_savings = insert_data($conn, $accounts_profit, "account_profits");

                
                //Profit add in account
                $profit_add_array = array(
                    "created_by" =>  $uid,
                    "created_at" =>   date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_ip" => $ip,
                    "account_no" => $account_id,
                    "account_no_full" => $account_details["full_ac_number"],
                    "basic_amount" => $account_details['basic_amount'],
                    "payment_for" => "Profit -" . $profit_category,
                    "installment_no" => 0,
                    "installment_time" => 0,
                    // "payment_type" => $payment_type,
                    // "payment_info" => $payment_info,
                    // "payment_photo" => $payment_photo,
                    // "fine" => $fine,
                    "total_tk" => $account_details['ac_profit'],
                    "short_details" => $profit_category,
                    // "profit" => $profit,
                    "status" => "paid",
                    "branch_id" => $account_details['branch']
                );

                $new_transection = insert_data($conn, $profit_add_array, "transections");
                $new_transection_id = $new_transection['last_id'];

                // $ck_result[] = $profit_add_array;
                // refer amount goes to staff_transections
                $my_ac_type = $account_type;;
                $my_ac =$account_details["full_ac_number"];
                $ac_with_type = "$my_ac_type-$my_ac";
                $refer_profit_array = array(
                    "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_by" => $uid,
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "transection_id" => $new_transection_id,
                    "staff_id" => $account_details['staff_ref'],
                    "short_details" => "Refer Amount",
                    "details" => $ac_with_type,
                    "earnings" => $account_details['refer_profit'],

                );
                insert_data($conn, $refer_profit_array, "staff_transections");

                $branch_commission_sql = array(
                    "created_id" =>  $uid,
                    "created_at" =>  date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "transection_id" => $new_transection_id,
                    "title" => "Profit Commisstion",
                    "info" => "Deposit ID:" . $account_details['full_ac_number'],
                    "deposit" => $account_details['institute_profit'],
                );
                $branch_commission_res = insert_data($conn, $branch_commission_sql, "branch_expenses");
                $total_deposit_profit_paid += $account_details['ac_profit'];
/*
                $i++;
                $sum_col_1 += $profit_amount;
                $sum_col_2 += $refer_profit;
                $sum_col_3 += $ac_profit;
                */
                // $return_message['insert_array'][$account_id] = print_r($account_details);
            }
        } elseif ($account_type == "savings") {
            foreach ($all_account_details as $account_id => $account_details) {
                // $return_message['ac_id'][] = $key.'savings';
                $accounts_profit = array(
                    "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_id" => $uid,
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "profit_code" => $profit_category,
                    "ac_id" => $account_id,
                    "ac_no_full" => $account_details["full_ac_number"],
                    "ac_type" => $account_type,
                    "refer_id" => $account_details['staff_ref'],
                    "total_profit" => $total_payable_profit,
                    "total_deposit_savings" => $total_savings_and_deposite,
                    "current_balance" => $account_details['total_balance'],
                    "profit_amount" => $account_details['profit_amount'],
                    "refer_amount" => $account_details['refer_profit'],
                    "branch_amount" => $account_details['institute_profit'],
                    "profit_received" => $account_details['ac_profit'],
                    "profit_withdraw" => 0,
                    "status" => "",
                    "notes" => ""
                );
                $insert_savings = insert_data($conn, $accounts_profit, "account_profits");
                // $ck_result[] = $accounts_profit;
                // $return_message['insert_array'][$account_id] = $accounts_profit;




                //Profit add in account
                $profit_add_array = array(
                    "created_by" =>  $uid,
                    "created_at" =>   date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_ip" => $ip,
                    "account_no" => $account_id,
                    "account_no_full" => $account_details["full_ac_number"],
                    "basic_amount" => $account_details['basic_amount'],
                    "payment_for" => "Profit -" . $profit_category,
                    "installment_no" => 0,
                    "installment_time" => 0,
                    // "payment_type" => $payment_type,
                    // "payment_info" => $payment_info,
                    // "payment_photo" => $payment_photo,
                    // "fine" => $fine,
                    "total_tk" => $account_details['ac_profit'],
                    "short_details" => "Profit",
                    // "profit" => $profit,
                    "status" => "paid",
                    "branch_id" => $account_details['branch']
                );

                $new_transection = insert_data($conn, $profit_add_array, "transections");
                $new_transection_id = $new_transection['last_id'];

                // refer amount goes to staff_transections
                $my_ac_type = $account_type;
                $my_ac = $account_details["full_ac_number"];
                $ac_with_type = "$my_ac_type-$my_ac";
                $refer_profit_array = array(
                    "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_by" => $uid,
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "transection_id" => $new_transection_id,
                    "staff_id" => $account_details['staff_ref'],
                    "short_details" => "Refer Amount",
                    "details" => $ac_with_type,
                    "earnings" => $account_details['refer_profit'],

                );
                insert_data($conn, $refer_profit_array, "staff_transections");

                $branch_commission_sql = array(
                    "created_id" =>  $uid,
                    "created_at" =>  date("Y-m-d H:i:s", strtotime($datetime)),
                    "created_ip" => $ip,
                    "branch_id" => $account_details['branch'],
                    "transection_id" => $new_transection_id,
                    "title" => "Profit Commisstion",
                    "info" => "Savings ID:" . $account_details['full_ac_number'],
                    "deposit" => $account_details['institute_profit'],
                );
                $branch_commission_res = insert_data($conn, $branch_commission_sql, "branch_expenses");


                $total_savings_profit_paid += $account_details['ac_profit'];
                // $i++;
                // $sum_col_1 += $profit_amount;
                // $sum_col_2 += $refer_profit;
                // $sum_col_3 += $ac_profit;

            }
        }
    }
    $title_array = array(
        "created_at" => date("Y-m-d H:i:s", strtotime($datetime)),
        "created_id" => $uid,
        "created_ip" => $ip,
        "title" => $profit_category,
        "savings_amount" => $total_savings_profit_paid,
        "deposite_amount" => $total_deposit_profit_paid,
        "profits_range" => "",
        "details" => ""
    );
    $insert_profit_title = insert_data($conn, $title_array, "profits_title");
    $unpaid_profit_sql = manual_query("SELECT * FROM `profits` WHERE status='unpaid'");
    while ($unpaid_profit_update_res = mysqli_fetch_assoc($unpaid_profit_sql['query'])) {
        // $total_profit += $unpaid_profit_res['total_profit'];
        // $loan_staff_amount += $unpaid_profit_res['staff_amount'];
        $total_payable_profit = $unpaid_profit_update_res['total_profit'] - $unpaid_profit_update_res['staff_amount'];
        $institue_amount = ($total_payable_profit * $institute_percent) / 100;
        $this_total_profit = $total_payable_profit-$total_institute_profits;
        $deposit_and_savings_amount = $this_total_profit / 2;
        $update_array = array(
            "status" => "paid",
            "paid_note" => $profit_category,
            "institute_amount" => $total_institute_profits,
            "deposit_amount" => $deposit_and_savings_amount,
            "savings_amount" => $deposit_and_savings_amount,
        );

        updatethis(array("id" => $unpaid_profit_update_res['id']), $update_array, "profits");
    }
    // echo json_encode($return_message);
    echo "Success";
} else {
    header("Location:error_500.php");
    exit;
}
