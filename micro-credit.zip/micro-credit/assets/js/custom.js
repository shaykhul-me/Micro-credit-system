//image Light box part
$(document).on("click", ".modal_image_item", function() {
    var img_link = $(this).attr("src");
    $("#image_show").attr("src", img_link);
    $("#image_show-modal").modal("show");

})