<?php
include "seassion.php";

$id = mysqli_real_escape_string($conn, $_GET['id']);
// Get the logical transaction ID from the requested detail row
$initial_sql = manual_query("SELECT transaction_id FROM transections_details WHERE id = '$id'");
$initial_row = mysqli_fetch_assoc($initial_sql['query']);

if (!$initial_row) {
    die("Transaction not found");
}

$transaction_id = $initial_row['transaction_id'];

// If transaction_id is present, fetch all related details. Otherwise just fetch the one.
if (!empty($transaction_id) && $transaction_id > 0) {
    $sql = manual_query("SELECT * FROM transections_details WHERE transaction_id = '$transaction_id'");
} else {
    $sql = manual_query("SELECT * FROM transections_details WHERE id = '$id'");
}

$rows = [];
$member_name = "";
$date = "";
$t_id = $transaction_id;
if(empty($t_id)) $t_id = $id;

$total_in = 0;
$total_out = 0;

while($r = mysqli_fetch_assoc($sql['query'])){
    $rows[] = $r;
    if(!empty($r['account_title']) && empty($member_name)) $member_name = $r['account_title'];
    if(empty($date)) $date = $r['created_at'];
    $total_in += $r['cash_in'];
    $total_out += $r['cash_out'];
}

// Fallback to fetch member name from parent transaction if not found in details (e.g. only Fine/Others)
if(empty($member_name) && !empty($transaction_id)) {
    $parent_query = manual_query("SELECT member_id FROM transections WHERE id='$transaction_id'");
    $parent_res = mysqli_fetch_assoc($parent_query['query']);
    if($parent_res && !empty($parent_res['member_id'])) {
         $member_id = $parent_res['member_id'];
         $mem_q = manual_query("SELECT name FROM members WHERE id='$member_id'");
         $mem_r = mysqli_fetch_assoc($mem_q['query']);
         if($mem_r) $member_name = $mem_r['name'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Memo</title>
    <style>
        @page {
            margin: 0;
            size: auto; 
        }
        body {
            font-family: 'Courier New', Courier, monospace; 
            background-color: #fff;
            padding: 0;
            margin: 0;
            font-size: 13px; /* Slightly larger for better readability */
            color: #000;
        }
        .memo-container {
            width: 100%; /* Use full width of the printer's printable area */
            max-width: 79mm; /* Safe zone for 80mm thermal paper */
            margin: 0 auto;
            padding: 2mm; /* Minimal padding */
            background: #fff;
            border: none;
            box-shadow: none;
        }
        .header {
            text-align: center;
            margin-bottom: 10px;
            border-bottom: 1px dashed #000;
            padding-bottom: 5px;
        }
        .header h1 {
            margin: 0;
            color: #000;
            font-size: 16px;
            text-transform: uppercase;
           
        }
        .header p {
            margin: 2px 0 0;
            color: #000;
            font-size: 10px;
        }
        .meta-info {
            margin-bottom: 10px;
        }
        .meta-info table {
            width: 100%;
        }
        .meta-info td {
            padding: 2px 0;
            vertical-align: top;
            font-size: 11px;
        }
        .transaction-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
        }
        .transaction-table th, .transaction-table td {
            border-bottom: 1px dashed #000;
            padding: 4px 2px;
            text-align: left;
            font-size: 11px;
        }
        .transaction-table th {
            background-color: transparent; /* No grey background for thermal */
            font-weight: bold;
            border-top: 1px dashed #000;
        }
        /* Hide complex borders from default table style */
        .transaction-table th, .transaction-table td {
            border-left: none;
            border-right: none;
            border-top: none; 
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: left; /* Center looks weird on small columns sometimes, but let's keep centered headings if needed. Actually simpler left/right alignment is better */
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            color: #000;
            border-top: 1px dashed #000;
            padding-top: 5px;
        }
        .signature-section {
            margin-top: 30px;
            display: flex;
            justify-content: space-between;
            display: none; /* Often removed for small POS receipts to save paper, or simplified */
        }
        /* Or if signature needed */
        .signature-box {
            text-align: center;
            width: 45%;
            border-top: 1px solid #000;
            padding-top: 2px;
            font-size: 10px;
        }

        .no-print {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
            background: #eee;
        }
        .btn {
            background: #000;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 2px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 0 5px;
            font-size: 12px;
        }
        .btn-close {
            background: #555;
        }
        @media print {
            .no-print {
                display: none;
            }
            .memo-container {
                width: 100%; /* Fill the paper width */
                max-width: 72mm;
                padding: 0;
                margin: 0;
            }
            body { 
                margin: 0; 
                padding: 0; 
            }
        }
    </style>
</head>
<body>

<div class="memo-container">
    <div class="header">
        <h1>Transaction Memo</h1>
        <p>Micro Credit Organization</p>
    </div>

    <div class="meta-info">
        <table>
            <tr>
                <td width="60%">
                    <!-- <strong>Name:</strong> <?php echo $member_name; ?> -->
                    <!-- In case we want to show Account Titles if different per row, we can skip here, but usually Member Name is Global -->
                    <strong>Member Name:</strong> <?php echo !empty($member_name) ? $member_name : "N/A"; ?>
                </td>
                <td width="40%" class="text-right">
                    <strong>Date:</strong> <?php echo date("d-M-Y h:i A", strtotime($date)); ?><br>
                    <strong>Transaction ID:</strong> <?php echo $t_id; ?>
                </td>
            </tr>
        </table>
    </div>

    <?php
    // Re-organize data by category for fixed structure display
    $data_map = [
        'Savings' => null,
        'Admission Fee' => null,
        'Share' => null,
        'Fine' => null,
        'Others' => null
    ];
    
    foreach($rows as $r){
        // Map categories. Adapting to exact strings if needed, but usually they match what was inserted.
        if(isset($data_map[$r['category']])){
             $data_map[$r['category']] = $r;
        } else {
             // Fallback or just add it if it's something else
             $data_map[$r['category']] = $r;
        }
    }
    ?>

    <table class="transaction-table">
        <thead>
            <tr>
                <th class="text-center" width="50px">ক্রমিক</th>
                <th class="text-center">বিবরণ</th>
                <th class="text-center" width="150px">টাকা</th>
            </tr>
        </thead>
        <tbody>
            <?php $sl = 1; ?>
            
            <!-- 1. Savings -->
            <?php 
            $sav = $data_map['Savings'];
            if($sav && $sav['cash_in'] > 0): 
            ?>
            <tr>
                <td class="text-center"><?php echo $sl++; ?>।</td>
                <td>
                    সঞ্চয় আমানত
                    <?php 
                        $monthly = isset($sav['monthly']) ? $sav['monthly'] : 0;
                        $months = isset($sav['months']) ? $sav['months'] : 0;
                        //$month_names = isset($sav['month_name']) ? rtrim($sav['month_name'], ',') : '';
                        echo ", মাসিক- $monthly TK, মাস- $months";
                    ?>
                </td>
                <td class="text-right">
                    <?php echo number_format($sav['cash_in'], 2); ?>
                </td>
            </tr>
            <?php endif; ?>

            <!-- 2. Admission Fee -->
            <?php 
            $adm = $data_map['Admission Fee'];
            if($adm && $adm['cash_in'] > 0):
            ?>
            <tr>
                <td class="text-center"><?php echo $sl++; ?>।</td>
                <td>ভর্তি ফি</td>
                <td class="text-right">
                     <?php echo number_format($adm['cash_in'], 2); ?>
                </td>
            </tr>
            <?php endif; ?>

            <!-- 3. Share -->
            <?php 
            $sha = $data_map['Share'];
            if($sha && $sha['cash_in'] > 0):
            ?>
             <tr>
                <td class="text-center"><?php echo $sl++; ?>।</td>
                <td>
                    শেয়ার
                    <?php 
                        $monthly = isset($sha['monthly']) ? $sha['monthly'] : 0;
                        $months = isset($sha['months']) ? $sha['months'] : 0;
                        echo ", মাসিক- $monthly TK, মাস- $months";
                    ?>
                </td>
                <td class="text-right">
                    <?php echo number_format($sha['cash_in'], 2); ?>
                </td>
            </tr>
            <?php endif; ?>

            <!-- 4. Fine -->
            <?php 
            $fine = $data_map['Fine'];
            if($fine && $fine['cash_in'] > 0):
            ?>
            <tr>
                <td class="text-center"><?php echo $sl++; ?>।</td>
                <td>জরিমানা</td>
                <td class="text-right">
                     <?php echo number_format($fine['cash_in'], 2); ?>
                </td>
            </tr>
            <?php endif; ?>

            <!-- 5. Others -->
            <?php 
            $oth = $data_map['Others'];
            if($oth && $oth['cash_in'] > 0):
            ?>
            <tr>
                <td class="text-center"><?php echo $sl++; ?>।</td>
                <td>বিবিধ</td>
                <td class="text-right">
                     <?php echo number_format($oth['cash_in'], 2); ?>
                </td>
            </tr>
            <?php endif; ?>
            
            <tr style="background-color: #f9f9f9; font-weight: bold;">
                <td colspan="2" class="text-right">মোট</td>
                <td class="text-right"><?php echo number_format($total_in, 2); ?></td>
            </tr>
        </tbody>
    </table>

    <!-- Signature often removed for POS or simplified -->
    <!-- 
    <div class="signature-section">
        <div class="signature-box">
            Customer Signature
        </div>
        <div class="signature-box">
            Officer Signature
        </div>
    </div> 
    -->
    <div style="margin-top: 15px; text-align: center; font-size: 10px;">
        <br>
        -----------------------<br>
        Officer Signature
    </div>

    <div class="footer">
        <p>Thank you for banking with us.</p>
        <p><?php echo date("d-M-Y h:i A"); ?></p>
    </div>
</div>

<div class="no-print">
    <button onclick="window.print()" class="btn">Print Memo</button>
    <button onclick="window.close()" class="btn btn-close">Close</button>
</div>

</body>
</html>
